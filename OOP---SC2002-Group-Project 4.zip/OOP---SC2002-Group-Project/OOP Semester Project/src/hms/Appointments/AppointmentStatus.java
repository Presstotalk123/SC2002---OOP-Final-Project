package hms.Appointments;

public enum AppointmentStatus {
  confirmed,
  cancelled,
  completed,
  pending
}
