package hms;

public enum Gender {
  Male,
  Female,
  Other
}
