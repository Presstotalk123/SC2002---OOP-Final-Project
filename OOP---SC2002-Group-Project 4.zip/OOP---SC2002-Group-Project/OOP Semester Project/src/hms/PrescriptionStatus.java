package hms;

public enum PrescriptionStatus {
  Pending,
  Dispensed
}
