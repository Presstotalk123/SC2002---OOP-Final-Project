package hms.MedicalRecords;

import java.io.IOException;
import java.util.Scanner;

public interface MedicalRecordPatientView {
  String toString();

  void updateEmailAddress(String email);

  void updatePhoneNumber(String phoneNumber);

  void saveToFile() throws IOException;

  

  void addDiagnosis(String diagnosis) throws IOException;

  void addTreatments(String treatment) throws IOException;
}